# dconf reset -f /  - to completely delete all settings
# dconf dump / > file-full-dump
# dconf load / > file-full-dump after changing

gsettings set org.blueberry use-symbolic-icons false
gsettings set org.gnome.desktop.background picture-uri 'file:///usr/share/backgrounds/arcolinux/arco-wallpaper.jpg'
